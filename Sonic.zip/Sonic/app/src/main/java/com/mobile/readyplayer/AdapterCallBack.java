package com.mobile.readyplayer;

public interface AdapterCallBack {
    void onMethodCallBack(int position);

    void changePlaylist(String playlist);
}
