package com.mobile.readyplayer.ui;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v4.app.JobIntentService;

public class MyIntentService extends JobIntentService {


    @Override
    protected void onHandleWork(@NonNull Intent intent) {

    }
}
