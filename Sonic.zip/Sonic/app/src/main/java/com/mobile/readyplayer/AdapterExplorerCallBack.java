package com.mobile.readyplayer;

public interface AdapterExplorerCallBack {

    void insideDirectory(String nameOfFile);
    void showFloatingActionButton(boolean listEmpty);
//    void onMethodCallBack(String nameOfFile);
//    void showFloatingActionButton(boolean appear);
//    void uncheckCheckAllButton();
//    boolean getStateCheckAllCheckboxes();
}
